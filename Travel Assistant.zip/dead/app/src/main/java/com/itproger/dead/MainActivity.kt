
package com.itproger.dead

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParserFactory
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var database: ChecklistDatabase
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var navigation: LinearLayout

    private var currentScreen = "Валюты"

    // Светлая цветовая гамма
    private val backgroundColor = Color.rgb(243, 246, 251)
    private val panelColor = Color.WHITE
    private val accentColor = Color.rgb(65, 119, 230)
    private val textColor = Color.rgb(35, 43, 59)
    private val secondaryColor = Color.rgb(105, 117, 137)
    private val borderColor = Color.rgb(225, 231, 240)

    private val currencyCodes = listOf(
        "RUB", "USD", "EUR", "CNY", "TRY",
        "GBP", "JPY", "KZT", "INR", "AED"
    )

    private var currencyRates: Map<String, Double> = mapOf("RUB" to 1.0)

    private lateinit var currencyStatus: TextView
    private lateinit var amountInput: EditText
    private lateinit var fromCurrency: Spinner
    private lateinit var toCurrency: Spinner
    private lateinit var conversionResult: TextView

    private var weatherRequestId = 0
    private lateinit var weatherCitySpinner: Spinner
    private lateinit var weatherContent: LinearLayout
    private lateinit var weatherStatus: TextView

    private data class City(
        val name: String,
        val country: String,
        val latitude: Double,
        val longitude: Double
    ) {
        override fun toString(): String = "$name — $country"
    }

    private val cities = listOf(
        City("Токио", "Япония", 35.6762, 139.6503),
        City("Дели", "Индия", 28.6139, 77.2090),
        City("Шанхай", "Китай", 31.2304, 121.4737),
        City("Дакка", "Бангладеш", 23.8103, 90.4125),
        City("Сан-Паулу", "Бразилия", -23.5505, -46.6333),
        City("Каир", "Египет", 30.0444, 31.2357),
        City("Мехико", "Мексика", 19.4326, -99.1332),
        City("Пекин", "Китай", 39.9042, 116.4074),
        City("Мумбаи", "Индия", 19.0760, 72.8777),
        City("Осака", "Япония", 34.6937, 135.5023),
        City("Чунцин", "Китай", 29.4316, 106.9123),
        City("Карачи", "Пакистан", 24.8607, 67.0011),
        City("Киншаса", "ДР Конго", -4.4419, 15.2663),
        City("Лагос", "Нигерия", 6.5244, 3.3792),
        City("Стамбул", "Турция", 41.0082, 28.9784),
        City("Буэнос-Айрес", "Аргентина", -34.6037, -58.3816),
        City("Колката", "Индия", 22.5726, 88.3639),
        City("Манила", "Филиппины", 14.5995, 120.9842),
        City("Гуанчжоу", "Китай", 23.1291, 113.2644),
        City("Шэньчжэнь", "Китай", 22.5431, 114.0579),
        City("Москва", "Россия", 55.7558, 37.6173),
        City("Санкт-Петербург", "Россия", 59.9311, 30.3609),
        City("Вильнюс", "Литва", 54.6872, 25.2797),
        City("Лондон", "Великобритания", 51.5072, -0.1276),
        City("Париж", "Франция", 48.8566, 2.3522),
        City("Берлин", "Германия", 52.5200, 13.4050),
        City("Нью-Йорк", "США", 40.7128, -74.0060),
        City("Лос-Анджелес", "США", 34.0522, -118.2437),
        City("Торонто", "Канада", 43.6532, -79.3832),
        City("Сеул", "Южная Корея", 37.5665, 126.9780),
        City("Джакарта", "Индонезия", -6.2088, 106.8456),
        City("Бангкок", "Таиланд", 13.7563, 100.5018),
        City("Сингапур", "Сингапур", 1.3521, 103.8198),
        City("Дубай", "ОАЭ", 25.2048, 55.2708),
        City("Сидней", "Австралия", -33.8688, 151.2093)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = backgroundColor
        window.navigationBarColor = backgroundColor
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                    View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        database = ChecklistDatabase(this)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(backgroundColor)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        val header = TextView(this).apply {
            text = "TravelAssistant"
            textSize = 25f
            setTextColor(textColor)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(20), dp(16), dp(16))
        }

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(12))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }

        navigation = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setBackgroundColor(panelColor)
        }

        root.addView(header)
        root.addView(content)
        root.addView(navigation)

        setContentView(root)
        showCurrencyScreen()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun makeText(
        value: String,
        size: Float = 16f,
        bold: Boolean = false,
        color: Int = textColor
    ): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(4), dp(6), dp(4), dp(6))
        }
    }

    private fun makeButton(label: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(Color.WHITE)
            backgroundTintList =
                android.content.res.ColorStateList.valueOf(accentColor)
            setOnClickListener { onClick() }
        }
    }

    private fun makePanel(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(panelColor)
            elevation = dp(2).toFloat()
        }
    }

    private fun showScreenTitle(title: String, subtitle: String? = null) {
        content.removeAllViews()
        content.addView(makeText(title, 23f, true))
        if (subtitle != null) {
            content.addView(
                makeText(subtitle, 14f, false, secondaryColor)
            )
        }
    }

    // -------------------- Нижнее меню --------------------

    private fun buildNavigation() {
        navigation.removeAllViews()

        val names = listOf("Валюты", "Сборы", "Погода")

        names.forEach { name ->
            val selected = currentScreen == name

            val button = TextView(this).apply {
                text = when (name) {
                    "Валюты" -> "💱\nВалюты"
                    "Сборы" -> "🎒\nСборы"
                    else -> "🌤️\nПогода"
                }
                gravity = Gravity.CENTER
                textSize = 14f
                setPadding(dp(8), dp(8), dp(8), dp(8))
                setTextColor(if (selected) Color.WHITE else secondaryColor)
                setBackgroundColor(if (selected) accentColor else panelColor)
                isClickable = true
                isFocusable = true

                setOnClickListener {
                    when (name) {
                        "Валюты" -> showCurrencyScreen()
                        "Сборы" -> showChecklistScreen()
                        "Погода" -> showWeatherScreen()
                    }
                }
            }

            navigation.addView(
                button,
                LinearLayout.LayoutParams(0, dp(58), 1f).apply {
                    setMargins(dp(4), 0, dp(4), 0)
                }
            )
        }
    }

    private fun selectScreen(name: String) {
        currentScreen = name
        buildNavigation()
    }

    // -------------------- Валюты --------------------

    private fun showCurrencyScreen() {
        selectScreen("Валюты")
        showScreenTitle(
            "Конвертер валют",
            "Курсы Центрального банка России"
        )

        val panel = makePanel()
        panel.addView(makeText("Сумма", 15f, true))

        amountInput = EditText(this).apply {
            hint = "Введите сумму"
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                    android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setTextColor(textColor)
            setHintTextColor(secondaryColor)
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }

        panel.addView(
            amountInput,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(52)
            )
        )

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            currencyCodes
        )
        adapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )

        panel.addView(makeText("Из валюты", 15f, true))

        fromCurrency = Spinner(this).apply {
            this.adapter = adapter
            setSelection(currencyCodes.indexOf("USD"))
        }

        panel.addView(
            fromCurrency,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(48)
            )
        )

        panel.addView(makeButton("⇅ Поменять валюты") {
            val oldFrom = fromCurrency.selectedItemPosition
            val oldTo = toCurrency.selectedItemPosition
            fromCurrency.setSelection(oldTo)
            toCurrency.setSelection(oldFrom)
            calculateCurrency()
        })

        panel.addView(makeText("В валюту", 15f, true))

        toCurrency = Spinner(this).apply {
            this.adapter = adapter
            setSelection(currencyCodes.indexOf("RUB"))
        }

        panel.addView(
            toCurrency,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(48)
            )
        )

        conversionResult = makeText("Результат появится здесь", 21f, true)
        panel.addView(conversionResult)

        panel.addView(makeButton("Конвертировать") {
            calculateCurrency()
        })

        currencyStatus = makeText(
            "Загружаю курсы валют…",
            13f,
            false,
            secondaryColor
        )
        panel.addView(currencyStatus)

        panel.addView(makeButton("Обновить курсы") {
            loadCurrencyRates()
        })

        content.addView(
            panel,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        amountInput.setText("100")
        loadCurrencyRates()
    }

    private fun loadCurrencyRates() {
        currencyStatus.text = "Загружаю актуальные курсы ЦБ РФ…"

        thread {
            try {
                val connection = URL(
                    "https://www.cbr.ru/scripts/XML_daily.asp"
                ).openConnection() as HttpURLConnection

                connection.connectTimeout = 10000
                connection.readTimeout = 10000
                connection.requestMethod = "GET"

                val parser = XmlPullParserFactory.newInstance().newPullParser()
                parser.setInput(
                    BufferedReader(
                        InputStreamReader(
                            connection.inputStream,
                            Charsets.UTF_8
                        )
                    )
                )

                val rates = mutableMapOf("RUB" to 1.0)
                var event = parser.eventType
                var currentCode = ""
                var nominal = 1.0
                var value = 0.0

                while (event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
                    if (event == org.xmlpull.v1.XmlPullParser.START_TAG) {
                        when (parser.name) {
                            "CharCode" -> currentCode = parser.nextText().trim()

                            "Nominal" -> {
                                nominal = parser.nextText()
                                    .trim()
                                    .replace(",", ".")
                                    .toDoubleOrNull() ?: 1.0
                            }

                            "Value" -> {
                                value = parser.nextText()
                                    .trim()
                                    .replace(",", ".")
                                    .toDoubleOrNull() ?: 0.0
                            }
                        }
                    } else if (
                        event == org.xmlpull.v1.XmlPullParser.END_TAG &&
                        parser.name == "Valute"
                    ) {
                        if (currentCode.isNotBlank() && value > 0 && nominal > 0) {
                            rates[currentCode] = value / nominal
                        }
                        currentCode = ""
                        nominal = 1.0
                        value = 0.0
                    }

                    event = parser.next()
                }

                connection.disconnect()

                runOnUiThread {
                    currencyRates = rates
                    currencyStatus.text =
                        "Курсы обновлены: " +
                                SimpleDateFormat(
                                    "dd.MM.yyyy HH:mm",
                                    Locale.getDefault()
                                ).format(Date())
                    calculateCurrency()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    currencyStatus.text =
                        "Не удалось загрузить курсы. Проверь интернет."
                }
            }
        }
    }

    private fun calculateCurrency() {
        val amount = amountInput.text.toString()
            .trim()
            .replace(",", ".")
            .toDoubleOrNull()

        if (amount == null) {
            conversionResult.text = "Введите корректную сумму"
            return
        }

        val from = fromCurrency.selectedItem?.toString() ?: "RUB"
        val to = toCurrency.selectedItem?.toString() ?: "RUB"

        val fromRate = currencyRates[from]
        val toRate = currencyRates[to]

        if (fromRate == null || toRate == null || toRate == 0.0) {
            conversionResult.text =
                "Курс для выбранной валюты недоступен"
            return
        }

        conversionResult.text = String.format(
            Locale.getDefault(),
            "%.2f %s",
            amount * fromRate / toRate,
            to
        )
    }

    // -------------------- Список сборов --------------------

    private fun showChecklistScreen() {
        selectScreen("Сборы")
        showScreenTitle(
            "Список сборов",
            "Добавляй вещи и отмечай уже собранные"
        )

        val panel = makePanel()

        val itemInput = EditText(this).apply {
            hint = "Например, паспорт"
            setSingleLine(true)
            setTextColor(textColor)
            setHintTextColor(secondaryColor)
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }

        panel.addView(
            itemInput,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(52)
            )
        )

        panel.addView(makeButton("＋ Добавить вещь") {
            val title = itemInput.text.toString().trim()

            if (title.isBlank()) {
                Toast.makeText(
                    this,
                    "Введите название вещи",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                database.addItem(title)
                showChecklistScreen()
            }
        })

        content.addView(
            panel,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        val items = database.getAllItems()
        val checkedCount = items.count { it.isChecked }

        content.addView(
            makeText("Собрано: $checkedCount из ${items.size}", 17f, true)
        )

        val progress = ProgressBar(
            this,
            null,
            android.R.attr.progressBarStyleHorizontal
        ).apply {
            max = if (items.isEmpty()) 1 else items.size
            this.progress = checkedCount
            progressTintList =
                android.content.res.ColorStateList.valueOf(accentColor)
        }

        content.addView(
            progress,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(10)
            ).apply {
                setMargins(0, dp(4), 0, dp(10))
            }
        )

        val listPanel = makePanel()
        val listLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        if (items.isEmpty()) {
            listLayout.addView(
                makeText(
                    "Список пока пуст. Добавь первую вещь выше.",
                    15f,
                    false,
                    secondaryColor
                )
            )
        } else {
            items.forEach { item ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(4), 0, dp(4))
                }

                val checkBox = CheckBox(this).apply {
                    text = item.title
                    isChecked = item.isChecked
                    setTextColor(textColor)
                    buttonTintList =
                        android.content.res.ColorStateList.valueOf(accentColor)

                    setOnCheckedChangeListener { _, checked ->
                        database.setChecked(item.id, checked)
                        showChecklistScreen()
                    }
                }

                row.addView(
                    checkBox,
                    LinearLayout.LayoutParams(
                        0,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        1f
                    )
                )

                val deleteButton = TextView(this).apply {
                    text = "✕"
                    textSize = 20f
                    gravity = Gravity.CENTER
                    setTextColor(Color.rgb(220, 70, 80))
                    setPadding(dp(12), dp(8), dp(12), dp(8))

                    setOnClickListener {
                        database.deleteItem(item.id)
                        showChecklistScreen()
                    }
                }

                row.addView(
                    deleteButton,
                    LinearLayout.LayoutParams(
                        dp(44),
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                )

                listLayout.addView(row)
            }
        }

        listPanel.addView(
            listLayout,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        val listScroll = ScrollView(this).apply {
            isFillViewport = true
            addView(
                listPanel,
                android.widget.FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
        }

        content.addView(
            listScroll,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )
    }

    // -------------------- Погода --------------------

    private fun showWeatherScreen() {
        selectScreen("Погода")
        showScreenTitle(
            "Погода",
            "Текущие условия и прогноз на 7 дней"
        )

        val cityAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            cities
        )
        cityAdapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )

        weatherCitySpinner = Spinner(this).apply {
            adapter = cityAdapter
            setSelection(cities.indexOfFirst { it.name == "Москва" })
        }

        content.addView(makeText("Выбери город", 15f, true))
        content.addView(
            weatherCitySpinner,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(48)
            )
        )

        content.addView(makeButton("Обновить погоду") {
            val city = weatherCitySpinner.selectedItem as? City
            if (city != null) loadWeather(city)
        })

        weatherStatus = makeText(
            "Загружаю погоду…",
            14f,
            false,
            secondaryColor
        )
        content.addView(weatherStatus)

        val scrollView = ScrollView(this)
        weatherContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        scrollView.addView(
            weatherContent,
            android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        content.addView(
            scrollView,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )

        weatherCitySpinner.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    loadWeather(cities[position])
                }

                override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            }

        loadWeather(cities.first { it.name == "Москва" })
    }

    private fun loadWeather(city: City) {
        val requestId = ++weatherRequestId
        weatherStatus.text = "Загружаю погоду для ${city.name}…"
        weatherContent.removeAllViews()

        thread {
            try {
                val url = URL(
                    "https://api.open-meteo.com/v1/forecast" +
                            "?latitude=${city.latitude}" +
                            "&longitude=${city.longitude}" +
                            "&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m" +
                            "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
                            "&forecast_days=7&timezone=auto"
                )

                val connection = url.openConnection() as HttpURLConnection
                connection.connectTimeout = 10000
                connection.readTimeout = 10000
                connection.requestMethod = "GET"

                val response = BufferedReader(
                    InputStreamReader(connection.inputStream, Charsets.UTF_8)
                ).use { it.readText() }

                connection.disconnect()

                val json = JSONObject(response)
                val current = json.getJSONObject("current")
                val daily = json.getJSONObject("daily")

                val temperature = current.optDouble("temperature_2m", Double.NaN)
                val feelsLike = current.optDouble("apparent_temperature", Double.NaN)
                val humidity = current.optInt("relative_humidity_2m", -1)
                val wind = current.optDouble("wind_speed_10m", Double.NaN)
                val code = current.optInt("weather_code", -1)

                val dates = daily.getJSONArray("time")
                val maxTemps = daily.getJSONArray("temperature_2m_max")
                val minTemps = daily.getJSONArray("temperature_2m_min")
                val codes = daily.getJSONArray("weather_code")
                val rain = daily.optJSONArray("precipitation_probability_max")

                runOnUiThread {
                    if (requestId != weatherRequestId) return@runOnUiThread

                    weatherStatus.text = "Погода в городе ${city.name}"
                    weatherContent.removeAllViews()

                    val currentPanel = makePanel()
                    currentPanel.addView(makeText(city.toString(), 19f, true))
                    currentPanel.addView(
                        makeText(
                            "${weatherEmoji(code)} ${weatherDescription(code)}",
                            18f,
                            true
                        )
                    )

                    currentPanel.addView(
                        makeText(
                            if (temperature.isNaN()) "Температура: —"
                            else "Температура: ${temperature.toInt()} °C",
                            25f,
                            true
                        )
                    )

                    currentPanel.addView(
                        makeText(
                            if (feelsLike.isNaN()) "Ощущается как: —"
                            else "Ощущается как: ${feelsLike.toInt()} °C"
                        )
                    )

                    currentPanel.addView(
                        makeText(
                            if (humidity < 0) "Влажность: —"
                            else "Влажность: $humidity%"
                        )
                    )

                    currentPanel.addView(
                        makeText(
                            if (wind.isNaN()) "Ветер: —"
                            else "Ветер: ${wind.toInt()} км/ч"
                        )
                    )

                    weatherContent.addView(
                        currentPanel,
                        LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply {
                            setMargins(0, dp(6), 0, dp(10))
                        }
                    )

                    weatherContent.addView(
                        makeText("Прогноз на 7 дней", 20f, true)
                    )

                    val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                    val displayFormat =
                        SimpleDateFormat("EEE, d MMM", Locale.getDefault())

                    for (i in 0 until dates.length()) {
                        val dateString = dates.optString(i)
                        val date = try {
                            displayFormat.format(
                                dateFormat.parse(dateString) ?: Date()
                            )
                        } catch (_: Exception) {
                            dateString
                        }

                        val max = maxTemps.optDouble(i, Double.NaN)
                        val min = minTemps.optDouble(i, Double.NaN)
                        val dayCode = codes.optInt(i, -1)

                        val rainChance =
                            if (rain != null && !rain.isNull(i)) rain.optInt(i, -1)
                            else -1

                        val dayPanel = makePanel().apply {
                            orientation = LinearLayout.HORIZONTAL
                            gravity = Gravity.CENTER_VERTICAL
                        }

                        val left = LinearLayout(this).apply {
                            orientation = LinearLayout.VERTICAL
                        }

                        left.addView(makeText(date, 15f, true))
                        left.addView(
                            makeText(
                                "${weatherEmoji(dayCode)} ${weatherDescription(dayCode)}",
                                13f,
                                false,
                                secondaryColor
                            )
                        )

                        dayPanel.addView(
                            left,
                            LinearLayout.LayoutParams(
                                0,
                                ViewGroup.LayoutParams.WRAP_CONTENT,
                                1f
                            )
                        )

                        val temps = if (max.isNaN() || min.isNaN()) {
                            "— / —"
                        } else {
                            "${max.toInt()}° / ${min.toInt()}°"
                        }

                        val rightText = buildString {
                            append(temps)
                            if (rainChance >= 0) {
                                append("\nДождь: $rainChance%")
                            }
                        }

                        dayPanel.addView(makeText(rightText, 14f, true))

                        weatherContent.addView(
                            dayPanel,
                            LinearLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT
                            ).apply {
                                setMargins(0, dp(3), 0, dp(3))
                            }
                        )
                    }

                    weatherContent.addView(
                        makeText(
                            "Источник данных: Open-Meteo",
                            12f,
                            false,
                            secondaryColor
                        )
                    )
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (requestId != weatherRequestId) return@runOnUiThread
                    weatherStatus.text =
                        "Не удалось загрузить погоду. Проверь интернет и попробуй обновить."
                }
            }
        }
    }

    private fun weatherEmoji(code: Int): String {
        return when (code) {
            0 -> "☀️"
            1, 2 -> "🌤️"
            3 -> "☁️"
            45, 48 -> "🌫️"
            51, 53, 55, 56, 57 -> "🌦️"
            61, 63, 65, 66, 67 -> "🌧️"
            71, 73, 75, 77 -> "❄️"
            80, 81, 82 -> "🌧️"
            85, 86 -> "🌨️"
            95, 96, 99 -> "⛈️"
            else -> "🌡️"
        }
    }

    private fun weatherDescription(code: Int): String {
        return when (code) {
            0 -> "Ясно"
            1 -> "Преимущественно ясно"
            2 -> "Переменная облачность"
            3 -> "Пасмурно"
            45, 48 -> "Туман"
            51 -> "Лёгкая морось"
            53 -> "Морось"
            55 -> "Сильная морось"
            56, 57 -> "Ледяная морось"
            61 -> "Небольшой дождь"
            63 -> "Дождь"
            65 -> "Сильный дождь"
            66, 67 -> "Ледяной дождь"
            71 -> "Небольшой снег"
            73 -> "Снег"
            75 -> "Сильный снег"
            77 -> "Снежные зёрна"
            80 -> "Небольшие ливни"
            81 -> "Ливни"
            82 -> "Сильные ливни"
            85, 86 -> "Снегопад"
            95 -> "Гроза"
            96, 99 -> "Гроза с градом"
            else -> "Нет описания"
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        database.close()
    }
}