
package com.itproger.dead

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class ChecklistItem(
    val id: Long,
    val title: String,
    val isChecked: Boolean
)

class ChecklistDatabase(context: Context) :
    SQLiteOpenHelper(context, "travel_checklist.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE checklist_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                is_checked INTEGER NOT NULL DEFAULT 0
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(
        db: SQLiteDatabase,
        oldVersion: Int,
        newVersion: Int
    ) {
        // При изменении структуры БД миграции добавим отдельно.
    }

    fun getAllItems(): List<ChecklistItem> {
        val result = mutableListOf<ChecklistItem>()
        val db = readableDatabase

        db.rawQuery(
            "SELECT id, title, is_checked FROM checklist_items ORDER BY id",
            null
        ).use { cursor ->
            while (cursor.moveToNext()) {
                result.add(
                    ChecklistItem(
                        id = cursor.getLong(0),
                        title = cursor.getString(1),
                        isChecked = cursor.getInt(2) == 1
                    )
                )
            }
        }

        return result
    }

    fun addItem(title: String): Long {
        val values = ContentValues().apply {
            put("title", title)
            put("is_checked", 0)
        }
        return writableDatabase.insert("checklist_items", null, values)
    }

    fun setChecked(id: Long, checked: Boolean) {
        val values = ContentValues().apply {
            put("is_checked", if (checked) 1 else 0)
        }
        writableDatabase.update(
            "checklist_items",
            values,
            "id = ?",
            arrayOf(id.toString())
        )
    }

    fun deleteItem(id: Long) {
        writableDatabase.delete(
            "checklist_items",
            "id = ?",
            arrayOf(id.toString())
        )
    }
}